# 🎤 GlobeWest Sprint 3 Demo Notes: My Account - Holds

---

### 1. Overview & Objective
- **Feature**: My Holds Customer Account Dashboard (`/gw_orders/hold/index/`)
- **Ticket**: [#41794528 - My Account - Holds](https://overdose.eu.teamwork.com/app/tasks/41794528)
- **Figma Reference**: Globewest USA - External ([Node 2581-64185 / Frame 621](https://www.figma.com/design/oSBa3EMR3goI0vM1tXCdTk/Globewest-USA---External?node-id=2581-64185&t=UHKXdUurQ7e08vqM-0))
- **Scope**: Trade customer portal for managing reserved inventory holds (2 business days reservation), order confirmation, search, and hold history.

---

### 2. Live Demo Script (Headed Mode)

#### A. Running the Automated Desktop Headed Walkthrough:
```bash
NODE_PATH="GlobeWest 2026/node_modules" node "Sprint-3/Ticket_41794528_My_Account_Holds/scripts/capture_live_desktop.js"
```

**Talking Points During Run**:
1. **Sidebar Hold Count Badge (Developer Vinod's Update - PASSED ✅)**:
   - Call out the blue counter pill badge (`.item__counter`) next to `Holds [5]` in the left sidebar account navigation.
   - Verified math: 3 Active Holds + 2 Inactive Holds = 5 Total Holds on record.
2. **Status Filter Tabs (PASSED ✅)**:
   - Show default `ACTIVE` tab selected with dark brown solid pill styling (`rgb(56, 28, 18)` / `#2B1D16`).
   - Demonstrate clean tab switching to `INACTIVE` tab showing expired holds and the warning notice banner.
3. **Table Architecture & Multi-Action Dropdown (CONFORMS TO SPEC ✅)**:
   - Frame 621 rule: *"if the only action available is view, hide column; otherwise actions housed under dropdown"*.
   - Live rows have multiple actions (`VIEW` + `MODIFY / CONFIRM`), correctly housed under the `Actions ⌵` dropdown.
4. **FAQ Accordion (PASSED ✅)**:
   - Show all accordions collapsed by default on initial render.
   - Demonstrate Frame 621 single-open auto-collapse rule: expanding Question 2 automatically collapses Question 1.
5. **Call Out Active Defects 🔴**:
   - **Date Format Leak**: Table displays Australian date format `14/10/26` (`DD/MM/YY`) instead of US standard `10/14/26` (`MM/DD/YYYY`).
   - **Header Typo**: Column 3 displays `CUST P0#` (digit 0) instead of `CUST PO#` (letter O).
   - **Subtitle Copy**: Subtitle uses Australian spelling `favourite` instead of US `favorite`.
   - **Support Phone Prefix**: Displays Australian phone `+613 9518 1600` on the US storefront.

---

#### B. Running the Automated Mobile Headed Walkthrough:
```bash
NODE_PATH="GlobeWest 2026/node_modules" node "Sprint-3/Ticket_41794528_My_Account_Holds/scripts/capture_live_mobile.js"
```

**Talking Points During Mobile Run**:
1. **Responsive Table Stacking**:
   - Layout stacks for mobile viewports (390px).
2. **Mobile Defects Callout**:
   - **Column Order Inversion**: Sequence displays `STATUS` before `TOTAL` (`HOLD | DATE | STATUS | TOTAL | ACTIONS`), whereas Figma specifies `HOLD | DATE | TOTAL | STATUS | ACTIONS`.
   - **Actions Button Clipping**: The 5th column `Actions` button overflows the right edge and gets clipped (`Ac`), requiring horizontal scrolling.

---

### 3. Deliverables & Test Suite Artifacts
- **Excel Test Cases (30 TCs)**: [My_Holds_Test_Cases.xlsx](file:///home/deepali/My%20Projects/Deepali/GlobeWest%202026%20(2)/Sprint-3/Ticket_41794528_My_Account_Holds/My_Holds_Test_Cases.xlsx)
- **CSV Test Cases (30 TCs)**: [My_Holds_Test_Cases.csv](file:///home/deepali/My%20Projects/Deepali/GlobeWest%202026%20(2)/Sprint-3/Ticket_41794528_My_Account_Holds/My_Holds_Test_Cases.csv)
- **Execution File**: [My Holds runcommand.txt](file:///home/deepali/My%20Projects/Deepali/GlobeWest%202026%20(2)/Sprint-3/Ticket_41794528_My_Account_Holds/My%20Holds%20runcommand.txt)
- **Interactive Figma Comparison Viewer**: [VIEW_FIGMA_COMPARISONS.html](file:///home/deepali/My%20Projects/Deepali/GlobeWest%202026%20(2)/Sprint-3/Ticket_41794528_My_Account_Holds/VIEW_FIGMA_COMPARISONS.html)
- **Comprehensive QA Audit Report**: [QA_AUDIT_REPORT.md](file:///home/deepali/My%20Projects/Deepali/GlobeWest%202026%20(2)/Sprint-3/Ticket_41794528_My_Account_Holds/QA_AUDIT_REPORT.md)
